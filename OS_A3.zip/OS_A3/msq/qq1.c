#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <unistd.h> 


struct st{
 
 int index[5];
 char mtext[5][4];
};
struct st1{
 
  long mtype;
 int ans;
}ret;
struct my_msgbuf {
    long mtype;
 //int index[5];
 struct st s[10];
}msg;


int main(void)
{char char_arr[50][4];
char string[4];

srand(time(NULL));
for(int j=0;j<50;j++){
for(int i=0;i<4;i++)
{
    string[i]='0'+rand()%72;
} 
strcpy(char_arr[j],string);
}
    
    int j=0;
    //struct st buf[10];
    for(int i=0;i<10;i++)
    {    (msg.s[i].index)[0]=j;
        (msg.s[i].index)[1]=j+1;
        (msg.s[i].index)[2]=j+2;
        (msg.s[i].index)[3]=j+3;
        (msg.s[i].index)[4]=j+4;
        for(int m=0;m<5;m++) 
        {
            for(int n=0;n<4;n++)
            {
                (msg.s[i].mtext)[m][n] = char_arr[j+m][n];
            }
        }
    j+=5;
    }
 int msqid;
 key_t key;
 int msqid2;
 key_t key2;
  if ((key = ftok("qq1.c", 'd')) == -1) { /* same key as kirk.c */
 perror("ftok");
 exit(1);
 }
  if ((key2 = ftok("qq2.c", 'd')) == -1) { /* same key as kirk.c */
 perror("ftok");
 exit(1);
 }
  
    
 if ((msqid = msgget(key,  0666 | IPC_CREAT)) == -1) { /* connect to the queue */
 perror("msgget");
 exit(1);
 }
 if ((msqid2 = msgget(key2,  0666 | IPC_CREAT)) == -1) { /* connect to the queue */
 perror("msgget2");
 exit(1);
 }
 int ans=0;int i=0;
    
  msg.mtype=1;
    
  while(i<10)
  {
    
    msgsnd(msqid, &msg, sizeof msg, 0);
  
    
    printf("index send till : %d \n", (msg.s[i].index)[4]);
//printf("%d",ans);
//
    if (msgrcv(msqid2, &ret, sizeof (ret), 2, 0) == -1) {
    perror("msgrcv");
    printf("err");
    exit(1);
     }
printf("%d",ret.ans);
     if(ret.ans==(msg.s[i].index)[4]){printf("found index");}
     else{ printf("index %d %d",ret.ans,(msg.s[i].index)[4] );break;}
i++;
  }


    return 0;
  
 
//  k++;
// }
//  if (msgctl(msqid, IPC_RMID, NULL) == -1) {
//  perror("msgctl");
//  exit(1);
//  }
//  return 0;
}