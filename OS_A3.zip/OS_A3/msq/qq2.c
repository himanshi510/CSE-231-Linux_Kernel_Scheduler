#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h> 
struct st{
 
 int index[5];
 char mtext[5][4];
};
struct st1{
 
  long mtype;
 int ans;
}ret;
struct my_msgbuf {
    long mtype;
 //int index[5];
 struct st s[10];
}msg;

int main(void)
{
 //struct my_msgbuf buf[10];
 int msqid;
 int msqid2;
 key_t key;

 key_t key2;
 if ((key = ftok("qq1.c", 'd')) == -1) { /* same key as kirk.c */
 perror("ftok");
 exit(1);
 }
 if ((key2 = ftok("qq2.c", 'd')) == -1) { /* same key as kirk.c */
 perror("ftok");
 exit(1);
 }
 if ((msqid = msgget(key, 0666)) == -1) { /* connect to the queue */
 perror("msgget");
 exit(1);
 }
 if ((msqid2 = msgget(key2, 0666)) == -1) { /* connect to the queue */
 perror("msgget2");
 exit(1);
 }

 printf("spock: ready to receive messages, captain.\n");
 int k=0;
 while(k<10){ 
     /* Spock enver quits! */
     printf("recieving\n");
 if (msgrcv(msqid,&msg,sizeof msg,1, 0) == -1) {
 perror("msgrcv");
 printf("err");
 exit(1);
 }
 for(int i=0;i<5;i++){
 printf("index reached %d ", (msg.s[k].index)[i]);
 for(int n=0;n<4;n++)
        {
            printf("%c",(msg.s[i].mtext)[i][n]);
        }printf("\n");
        }

    printf("recieved finish\n");
          ret.mtype=2;
int c=(msg.s[k].index)[4];
ret.ans=c;

 if(msgsnd(msqid2, &ret, sizeof (ret), 0)==-1)
 {printf("send error");perror("msgsnd");}
 else{printf("index sent %d ",(msg.s[k].index)[4]);}

 
 k++;
 }

 
 return 0;
}
