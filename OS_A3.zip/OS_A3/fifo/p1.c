#include <stdio.h>

#include <unistd.h>

#include <sys/socket.h>

#include <sys/un.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include <stdlib.h>
#define FIFO_NAME "fifo"

int main(void)

{  
    
    struct st

{
    int index[5];
char array[5][4];

};
char char_arr[50][4];
char string[4];

srand(time(NULL));
for(int j=0;j<50;j++){
for(int i=0; i<4;i++){
string[i]='0'+rand()%72; 
} 
strcpy(char_arr[j],string);
}

//           printf("bye %s",char_arr[i]);
        

//            }
//    }char s[300]={"himanshi"};

int num, fd;

//mknod("fifo", S_IFIFO | 0666, 0);
//mknod("fifo",  0666);


printf("waiting for readers...\n");


printf("got a reader--type some stuff\n");

// while (fgets(s), !feof(stdin))
struct st rec[10];
// {
    int j=0;
int k=0;
for(int i=0;i<10;i++)
{
    
    (rec[i].index)[0]=j;
    (rec[i].index)[1]=j+1;
    (rec[i].index)[2]=j+2;
    (rec[i].index)[3]=j+3;
    (rec[i].index)[4]=j+4;
    for(int m=0;m<5;m++) 
    {
        for(int n=0;n<4;n++)
        {
             (rec[i].array)[m][n] = char_arr[j+m][n];
        }
    }

    
j+=5;
}

int ans;k=0;
int num1;
int fd1;
while(k<10)
{

    fd1 = open("ff1", O_WRONLY);
    fd= open("ff2", O_RDONLY);

 if ((num = write(fd1, &rec[k], 400)) == -1)

{perror("write");}

 printf("speak: wrote %d bytes\n", num);

   // fd1 = open("fifo", O_RDONLY);

    //  if ((num = read(fd, &(rec[k].index)[4], sizeof(int))) == -1)///change
    //  {perror("read");}
 if ((num = read(fd, &ans, sizeof(int))) == -1)///change
     { printf("read error");perror("read");
    
     }
    else 
    {
        
        if(ans==(rec[k].index)[4])
        printf("found index %d",ans);
        
        else { printf("index not found %d %d %d",k,ans,(rec[k].index)[4]);break;}
        
        }

//close(fd1);


k++;}
// }

return 0;

}
