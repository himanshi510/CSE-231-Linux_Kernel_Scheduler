#include <stdio.h>

#include <unistd.h>


#include <sys/un.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
//#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>

#include <stdlib.h>
#define FIFO_NAME "fifo"

int main(void)

{ 
    char s[300];
char char_arr[50][4];

int num, fd;

   struct st

{
    int index[5];
char array[5][4];

};
//int ret;
//mknod("fifo", S_IFIFO | 0666, 0);
//ret=mkfifo("ff1",0666);
//ret=mkfifo("ff1",0666);
int ret;
//mknod("fifo", S_IFIFO | 0666, 0);
ret=mkfifo("ff1",0666);
ret=mkfifo("ff2",0666);
printf("waiting for writers...\n");
int i=0;
int fd2;
while(i<10){
fd = open("ff1", O_RDONLY);


fd2 = open("ff2",  O_WRONLY);

printf("got a reader--type some stuff\n");
struct st rec[10];
int num1;
// do

// {
int i=0;
  // int i=0;
// while(i<10 && num>0){
  
 if ((num = read(fd, &rec[i], 400)) == -1)
 perror("read");
  if (num == -1) {

perror("read");

exit(-1);

}

else if (num == 0) {

printf("EOF\n");
//close(fd);
exit(-1);


} 
 else {
 for(int m=0;m<5;m++){
     if(m==0 && i>0) {printf("index is  %d ",(rec[i].index)[m]+1);}
else{printf("index is  %d ",(rec[i].index)[m]);}
        for(int n=0;n<4;n++)
        {
            printf("%c",(rec[i].array)[m][n]);
        }printf("\n");
    }}

//close(fd);  
num1;

  if ((num1 = write(fd2, &(rec[i].index)[4], sizeof(int))) == -1)
   {perror("write");}
    else 
    {printf("wrote index %d",(rec[i].index)[4]);
    
        printf("\n");
    }
 

//close(fd2);

i++;
// printf("%s ",(rec[i].array)[3]);
// printf("index is %d ",(rec[i].index)[4]);

// printf("%s ",(rec[i].array)[4]);
    

}
   




// } while (num>0);

return 0;

}