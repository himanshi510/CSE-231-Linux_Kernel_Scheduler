#include <sys/socket.h>

#include <sys/un.h>

#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include <stdlib.h>
#include <stdlib.h>

#include <unistd.h>

char *socket_path = "\0hidden";

int main(int argc, char *argv[]) {

struct sockaddr_un addr;

char buf[100];

  struct st

{
    int index[5];
char array[5][4];

};
char char_arr[50][4];
char string[4];
struct st rec[10];


srand(time(NULL));
for(int j=0;j<50;j++){
for(int i=0;i<4;i++){
    string[i] ='0'+rand()%72; 
} 
strcpy(char_arr[j],string);
}
 int j=0;
 int k=0;
for(int i=0;i<10;i++)
{
    
    (rec[i].index)[0]=j;
    (rec[i].index)[1]=j+1;
    (rec[i].index)[2]=j+2;
    (rec[i].index)[3]=j+3;
    (rec[i].index)[4]=j+4;
    for(int m=0;m<5;m++) 
    {
        for(int n=0;n<4;n++)
        {
             (rec[i].array)[m][n] = char_arr[j+m][n];
        }
    }

    
j+=5;
}

int cl;
int fd,rc;

if (argc > 1) socket_path=argv[1];

if ( (fd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {perror("socket error");

exit(-1); }

memset(&addr, 0, sizeof(addr));

addr.sun_family = AF_UNIX;

if (*socket_path == '\0') {

*addr.sun_path = '\0';

strncpy(addr.sun_path+1, socket_path+1, sizeof(addr.sun_path)-2);

} else {strncpy(addr.sun_path, socket_path, sizeof(addr.sun_path)-1); }

if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) == -1) {

perror("connect error");

exit(-1);

}
k=0;
// {
 j=0;
//int k=0;
for(int i=0;i<10;i++)
{
    
    (rec[i].index)[0]=j;
    (rec[i].index)[1]=j+1;
    (rec[i].index)[2]=j+2;
    (rec[i].index)[3]=j+3;
    (rec[i].index)[4]=j+4;
    for(int m=0;m<5;m++) 
    {
        for(int n=0;n<4;n++)
        {
             (rec[i].array)[m][n] = char_arr[j+m][n];
        }
    }

    
j+=5;
}
int num;
int num1;
int ans;

while( k < 10) {
    
if ((num = write(fd, &rec[k], 400)) == -1)

{perror("write");exit(-1);}
//if (write(fd, buf, rc) != rc) {

//if (rc > 0) fprintf(stderr,"partial write");

else {
    printf("written ");
 }
 
if ((num1 = read(fd, &ans, sizeof(int))) == -1)//
     {perror("read");}
    else 
    {
        
        if(ans==(rec[k].index)[4])
        printf("found index %d",ans);
        
        else {break;}}
 
k++;

}
return 0;

}