#include <stdio.h>

#include <unistd.h>

#include <sys/socket.h>

#include <sys/un.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include <stdlib.h>

#include <stdlib.h>

char *socket_path = "\0hidden";

int main(int argc, char *argv[]) {

struct sockaddr_un addr;
struct st

{
    int index[5];
char array[5][4];

};
char char_arr[50][4];
struct st rec[10];

char buf[100];

int fd,cl,rc;

if (argc > 1) socket_path=argv[1];

if ( (fd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {

perror("socket error");

exit(-1); }

memset(&addr, 0, sizeof(addr));

addr.sun_family = AF_UNIX;

if (*socket_path == '\0') {

*addr.sun_path = '\0';

strncpy(addr.sun_path+1, socket_path+1, sizeof(addr.sun_path)-2);

} else { strncpy(addr.sun_path, socket_path, sizeof(addr.sun_path)-1);

unlink(socket_path); }

if (bind(fd, (struct sockaddr*)&addr, sizeof(addr)) == -1) { perror("bind error");

exit(-1); }

if (listen(fd, 5) == -1) {perror("listen error"); exit(-1); }
int k=0;
for(int k=0;k<10;k++){
for (;;) {
if ( (cl = accept(fd, NULL, NULL)) == -1) {
       
            perror("accept");
            exit(EXIT_FAILURE);
        }
        
        printf("Connection accepted from client\n");
       
           //int num1;

while ( (rc=read(cl, &rec[k], 400)) > 0) {

 for(int m=0;m<5;m++){
     if(m==0 && k>0) {printf("index is  %d ",(rec[k].index)[m]);}
else{printf("index is  %d ",(rec[k].index)[m]);}
        for(int n=0;n<4;n++)
        {
            printf("%c",(rec[k].array)[m][n]);
        }printf("\n");
    }

int num1;
  if ((num1 = write(cl, &(rec[k].index)[4], sizeof(int))) == -1)
   {perror("write");}
    else 
    {printf("wrote index");
    
        printf("\n");
    }


}
   

if (rc == -1) {

perror("read");

exit(-1);

}

else if (rc == 0) {

printf("EOF\n");
close(cl);
exit(-1);


}
// int num1;
//   if ((num1 = write(fd, &(rec[k].index)[4], sizeof(int))) == -1)
//     {perror("write");}
//     else 
//     {printf("wrote index");
    
//         printf("\n");
//     }
        }

}       


return 0;}
